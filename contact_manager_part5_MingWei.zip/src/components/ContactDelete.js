import { Link } from "react-router-dom";

function ContactDelete(props) {
  return (
    <div className="ui container center aligned">
      <div>
        <h3>Are you sure you want to delete the contact?</h3>
      </div>

      <div>
        <div>
          <button className="ui button blue" onClick={props.onConfirm}>
            Yes
          </button>
          <Link to={"/"}>
            <button className="ui button red" onClick={props.onCancel}>
              No
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default ContactDelete;
