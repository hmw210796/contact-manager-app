import { Fragment, useContext, useState } from "react";
import { Link } from "react-router-dom";
import ContactContext from "../context/contacts-context";
import user1 from "../image/user1.jpg";
import ContactDelete from "./ContactDelete";

function ContactCard(props) {
  const contactCtx = useContext(ContactContext);

  const [toDeleteModal, setToDeleteModal] = useState(false);

  const { id, name, email } = props.list;

  const removeContactHandler = () => {
    setToDeleteModal(true);
  };

  return (
    <Fragment>
      <div className="ui item row ">
        <img
          src={user1}
          alt="user-profile"
          className="ui image avatar left floated"
        />
        <div className="content">
          <Link to={{ pathname: `/contact/${id}` }}>
            <div className="header">{name}</div>
            <div>{email}</div>
          </Link>
        </div>

        <i
          className="trash alternate outline icon right floated"
          style={{
            color: "red",
            marginTop: "20px",
            marginLeft: "15px",
            cursor: "pointer",
          }}
          onClick={removeContactHandler}
        ></i>

        <Link to={{ pathname: `/contact/edit/${id}` }}>
          <i
            className="edit alternate outline icon right floated"
            style={{ color: "blue", marginTop: "20px" }}
          ></i>
        </Link>
      </div>
      {toDeleteModal && (
        <ContactDelete
          onConfirm={() => {
            contactCtx.onRemoveContact(id);
            setToDeleteModal(false);
          }}
          onCancel={() => {
            setToDeleteModal(false);
          }}
        />
      )}
    </Fragment>
  );
}

export default ContactCard;
